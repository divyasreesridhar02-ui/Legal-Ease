# LegalEase — Demo Deployment

This version is prepared for a one-link Streamlit Community Cloud demo.

## Important
- `app.py` runs the public demo directly through Streamlit.
- `main.py` and `routes.py` are retained for the college's FastAPI architecture.
- Do not upload a real Gemini API key to GitHub.
- On Streamlit Community Cloud, add this secret:

```toml
GEMINI_API_KEY = "YOUR_KEY_HERE"
GEMINI_MODEL = "gemini-2.5-flash"
```

If the key is not supplied, LegalEase still shows a deterministic demo document so the UI can be demonstrated.
