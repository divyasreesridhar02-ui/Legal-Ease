import os
from dotenv import load_dotenv

load_dotenv()

class GeminiDocumentGenerator:
    """
    Gemini-backed generator with a deterministic demo fallback.
    Put GEMINI_API_KEY in .env to enable AI generation.
    """

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    def generate_document(self, document_type, parties, terms, dates):
        if self.api_key:
            try:
                from google import genai
                client = genai.Client(api_key=self.api_key)
                prompt = f"""
You are a legal-document drafting assistant for an educational software project.
Create a structured draft for the following document.

Document type: {document_type}
Parties: {parties}
Effective date: {dates}
Terms: {terms}

Use clear headings:
TITLE
PARTIES
EFFECTIVE DATE
PURPOSE
TERMS AND CONDITIONS
CONFIDENTIALITY (where relevant)
TERMINATION
GENERAL PROVISIONS
SIGNATURES

Do not invent personal details. Clearly identify it as a draft and recommend professional legal review.
"""
                response = client.models.generate_content(
                    model=self.model_name,
                    contents=prompt
                )
                return response.text
            except Exception:
                # If API/model setup is unavailable, keep the project demonstrable.
                pass

        return self.demo_document(document_type, parties, terms, dates)

    def demo_document(self, document_type, parties, terms, dates):
        bullets = [x.strip() for x in terms.split(";") if x.strip()]
        term_lines = "\n".join(f"{i}. {t}" for i, t in enumerate(bullets, 1))
        return f"""LEGAL DOCUMENT DRAFT

{document_type.upper()}

PARTIES
{parties}

EFFECTIVE DATE
{dates}

PURPOSE
This document records the understanding between the parties identified above
for the purpose described by the selected document type.

TERMS AND CONDITIONS
{term_lines}

GENERAL PROVISIONS
The parties agree to act in accordance with the terms stated in this draft.
Any amendment should be made in writing and accepted by the relevant parties.

SIGNATURES

Party 1: ______________________________

Party 2: ______________________________

Date: _________________________________

IMPORTANT NOTICE
This is an educational AI-generated draft. It should be reviewed and adapted
by a qualified legal professional before being used for a real legal matter.
"""
