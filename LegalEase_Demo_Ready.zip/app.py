import os
from datetime import date
import streamlit as st

from ai_core.gemini_generator import GeminiDocumentGenerator
from utils.document_export import make_docx, make_pdf

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

# Streamlit Community Cloud secrets -> environment variable
try:
    if "GEMINI_API_KEY" in st.secrets:
        os.environ["GEMINI_API_KEY"] = st.secrets["GEMINI_API_KEY"]
    if "GEMINI_MODEL" in st.secrets:
        os.environ["GEMINI_MODEL"] = st.secrets["GEMINI_MODEL"]
except Exception:
    pass

st.title("⚖️ LegalEase")
st.subheader("AI-Powered Legal Document Generator")
st.caption("Generate, edit and export structured legal-document drafts.")

DOC_TYPES = [
    "NDA (Non-Disclosure Agreement)",
    "Employment Contract",
    "Lease Agreement",
    "Freelance Work Contract",
    "General Agreement",
    "Employment Offer Letter",
]

with st.form("legal_form"):
    document_type = st.selectbox("Document Type", DOC_TYPES)
    parties = st.text_area(
        "Parties Involved",
        placeholder="Example: Jane Doe (Service Provider), TechNova Inc. (Client)"
    )
    terms = st.text_area(
        "Terms & Conditions",
        placeholder="Enter each term separated by semicolons;\nPayment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice"
    )
    effective_date = st.date_input("Effective Date", value=date.today())
    submitted = st.form_submit_button("Generate Document")

if submitted:
    if not parties.strip() or not terms.strip():
        st.error("Please enter the parties and terms.")
    else:
        generator = GeminiDocumentGenerator()
        document = generator.generate_document(
            document_type=document_type,
            parties=parties,
            terms=terms,
            dates=str(effective_date),
        )
        st.session_state["document"] = document
        st.success("Document generated successfully.")

if "document" in st.session_state:
    st.divider()
    st.subheader("Generated Document")
    edited = st.text_area(
        "Click here to edit the document",
        value=st.session_state["document"],
        height=500,
    )
    st.session_state["document"] = edited

    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            "Download TXT",
            data=edited,
            file_name="LegalEase_Document.txt",
            mime="text/plain",
        )

    with col2:
        docx_bytes = make_docx(edited)
        st.download_button(
            "Download DOCX",
            data=docx_bytes,
            file_name="LegalEase_Document.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

    with col3:
        pdf_bytes = make_pdf(edited)
        st.download_button(
            "Download PDF",
            data=pdf_bytes,
            file_name="LegalEase_Document.pdf",
            mime="application/pdf",
        )

st.divider()
st.caption("LegalEase is an educational project and does not replace advice from a qualified legal professional.")
