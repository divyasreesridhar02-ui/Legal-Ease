# LegalEase – AI-Powered Legal Document Generator

## 1. Project purpose
LegalEase is a BCA educational project based on the college-provided specification. It uses a Streamlit frontend, FastAPI backend, and Gemini AI integration to create editable legal-document drafts.

## 2. Features
- Document type selection
- Parties and terms input
- Effective date
- AI-generated document draft through Gemini
- Demo fallback when an API key is not configured
- Editable generated text
- TXT download from the Streamlit interface
- DOCX/PDF export utility
- FastAPI /generate endpoint

## 3. Folder structure
LegalEase/
  app.py
  main.py
  routes.py
  requirements.txt
  .env
  ai_core/gemini_generator.py
  utils/document_export.py

## 4. Installation on a laptop/college computer
Open a terminal in the LegalEase folder:

python -m venv venv

Windows:
venv\Scripts\activate

Then:
pip install -r requirements.txt

Copy .env.example to .env and add a Gemini API key if your college permits API use.

## 5. Start the backend
uvicorn main:app --reload

Keep this terminal running.

## 6. Start the frontend
Open another terminal:
streamlit run app.py

The browser will open the Streamlit application.

## 7. Testing
Try:
Document type: Freelance Work Contract
Parties: Jane Doe (Service Provider), TechNova Inc. (Client)
Terms: Payment within 30 days; Confidentiality must be maintained; Work must be delivered by the agreed deadline; Either party may terminate with 15 days notice
Date: 2026-09-27

## 8. Important
The generated text is a draft for an educational project. It should not be treated as legal advice or used for a real legal matter without qualified legal review.

## 9. Team submission
Use the report and PPT supplied with this package. Replace placeholders such as college name, department, student names, register numbers and guide name.
