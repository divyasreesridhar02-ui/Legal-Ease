from utils.document_export import make_docx, make_pdf

sample = """LEGAL DOCUMENT DRAFT

FREELANCE WORK CONTRACT

PARTIES
Jane Doe (Service Provider), TechNova Inc. (Client)

EFFECTIVE DATE
2026-09-27

TERMS AND CONDITIONS
1. Payment within 30 days.
2. Confidentiality must be maintained.
3. Work must be delivered by the agreed deadline.
"""

with open("sample.txt", "w", encoding="utf-8") as f:
    f.write(sample)

with open("sample.docx", "wb") as f:
    f.write(make_docx(sample))

with open("sample.pdf", "wb") as f:
    f.write(make_pdf(sample))

print("Created sample.txt, sample.docx and sample.pdf")
